﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuscarLibro
{
    internal class Libro2
    {
       // private int ISBN = 012;
       //private string Autor = "Juanito";
       // private string Titulo= "Mexico";
       // private double NumPag = 500;
    }
}
