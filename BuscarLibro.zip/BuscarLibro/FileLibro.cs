﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuscarLibro
{
    internal class FileLibro
    {
        List<Libro> l = new List<Libro>();
        static List<Libro> libroList = new List<Libro>();

        public static void AddLibro(Libro libro)
        {
            libroList.Add(libro);
        }
        public static Libro FindLibro(int index)
        {
            Libro librol = new Libro();
            librol.ISBN = libroList[index].ISBN;
            librol.Titulo = libroList[index].Titulo;
            librol.Autor = libroList[index].Autor;
            librol.NumPag = libroList[index].NumPag;
            


            return librol;
        }
        public static List<Libro> ImprimirLista()
        {
            return libroList;

        }
    }
}
