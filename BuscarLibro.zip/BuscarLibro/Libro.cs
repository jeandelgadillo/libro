﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuscarLibro
{
    internal class Libro
    {

        public int ISBN { get; set; }
        public string Autor { get; set; }
        public string Titulo { get; set; }
        public double NumPag { get; set; }
     

        public int Mostrar(int ISBN, string Autor, string Titulo, double NumPag)
        {
            ISBN = ISBN;
            Autor = Autor;
            Titulo = Titulo;
            NumPag = NumPag;

            return ISBN;
        }
        public List<Libro> Tabla(int ISBN, string Autor, string Titulo, double NumPag)
        {



            List<Libro> l = new List<Libro>();
            Libro libro = new Libro();
            libro.ISBN = ISBN;
            libro.Titulo = Titulo;
            libro.Autor = Autor;
            libro.NumPag = NumPag;

            l.Add(libro);







            return l;

        }

        internal IEnumerable<Libro> Tabla(string autor, int iSBN, string titulo, double numPag)
        {
            throw new NotImplementedException();
        }
    }
}
