﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace BuscarLibro
{
    public partial class Form1 : Form
    {
        Libro l = new Libro();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            //int ISBN = Convert.ToInt32(this.txtISBN.Text);
            //string Autor = Convert.ToString(this.txtAutor.Text);
            //string Titulo = Convert.ToString(this.txtTitulo.Text);
            //double NumPag = Convert.ToDouble(this.txtNumPag.Text);

            //int cont = 0;
            //foreach (Libro libro in l.Tabla(Autor, ISBN, Titulo, NumPag))
            // {
            //this.dtpago.Rows.Insert(0, libro.ISBN, libro.Titulo, libro.NumPag, libro.Autor);


            //cont++;
            //}
            Libro l = new Libro();
            dtpago.Rows.Add(l);
            dtpago.Rows.Clear();
            dtpago[0, 0].Value = txtISBN.Text;
            dtpago[1, 0].Value = txtAutor.Text;
            dtpago[2, 0].Value = txtTitulo.Text;
            dtpago[3, 0].Value = txtNumPag.Text;

            //Libro (txtISBN, txtAutor, txtTitulo, txtNumPag)
            MessageBox.Show("Registro Agregado");

                //LimpiarTextboxs();
            //}
        }

        private void button1_Click(object sender, EventArgs e)
        {

            foreach(DataGridViewRow Row in dtpago2.Rows)
            {
                int strfile = Convert.ToInt32(Row.Index.ToString());
                string valor = Convert.ToString(Row.Cells["ISBN2"].Value);
                dtpago2[0, 0].Value = txtISBN.Text;
                dtpago2[1, 0].Value = txtAutor.Text;
                dtpago2[2, 0].Value = txtTitulo.Text;
                dtpago2[3, 0].Value = txtNumPag.Text;
                //dtpago.Rows.Add(l);
                //if (valor == this.txtBuscar.Text)
                //{

                //}
            }
            if (txtBuscar.Text == "") 
            {
                MessageBox.Show("Llene el campo");
            }

            //try
            //{

            //    int ISBN = Convert.ToInt32(Interaction.InputBox("Ingrese el ISBN del Libro", "Buscar Libro"));



            //    if (FileLibro.ImprimirLista().Count == ISBN)
            //    {
            //        //dtpago.Rows.Add();
            //        var libro = FileLibro.FindLibro(ISBN);
            //        dtpago[0, 0].Value = txtISBN.Text;
            //        dtpago[1, 0].Value = txtAutor.Text;
            //        dtpago[2, 0].Value = txtTitulo.Text;
            //        dtpago[3, 0].Value = txtNumPag.Text;

            //        this.dtpago.Rows.Clear();

            //        dtpago.Rows.Insert(0, libro.ISBN, libro.Autor, libro.Titulo, libro.NumPag);
            //        //dtpago[0, 0].Value = txtISBN.Text;
            //        //dtpago[1, 0].Value = txtAutor.Text;
            //        //dtpago[2, 0].Value = txtTitulo.Text;
            //        //dtpago[3, 0].Value = txtNumPag.Text;

            //    }
            //    else
            //    {
            //        MessageBox.Show("No existe el Registro Solicitado");



            //    }
            //}
            //catch (Exception exception)
            //{
            //    MessageBox.Show("Dato Invalido y/o Cancelado");
            //}
        }

        private void txtNumPag_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo Ingrese Números", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
                ;
            }
        }

        private void txtISBN_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo Ingrese Números", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
                ;
            }
        }
        public void LimpiarTextboxs()
        {
            this.txtISBN.Text = String.Empty;
            this.txtAutor.Text = String.Empty;
            this.txtTitulo.Text = String.Empty;
            this.txtNumPag.Text = String.Empty;
        }
    }
}
